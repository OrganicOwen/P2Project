﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Xml.Linq;
using static System.Windows.Forms.AxHost;

namespace rideTheBus
{
    public partial class loginPage : Form
    {
        public loginPage()
        {
            InitializeComponent();
            userPassError.Hide();
        }
        string username;
        string password;
        string userToLst;
        string passToLst;
        
        string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\lamarraoa57\\OneDrive - Northwood University\\Programming\\rideTheBus\\Database1.mdf\";Integrated Security=True";
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnOption3_Click(object sender, EventArgs e)
        {

        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            bool isTrue = false;
            username = usernameTxtBox.Text;
            password = passwordTxtBox.Text;
            SqlConnection cnnFind = new SqlConnection(connectionString);
            string queryString = "SELECT * from [user] Where username = username";
            using (SqlCommand cmdFindtax = cnnFind.CreateCommand())
            {
                
                cnnFind.Close();
                cmdFindtax.CommandText = queryString;
                cnnFind.Open();
                using (SqlDataReader reader = cmdFindtax.ExecuteReader())
                {
                     
                    while (reader.Read()) //tests if the password matches the username
                    {
                        userToLst = reader["username"].ToString();
                        passToLst = reader["password"].ToString();
                        if (password == passToLst && username == userToLst)
                        {  isTrue = true; }
                        //lstBox.Items.Add(userToLst + "-" + passToLst);
                        //StateTaxes = new string[] { TaxRate.ToString() };
                    }
                    
                    
                }
                //conn.Close();
            }
            if (isTrue)
            {
                userPassError.Hide();
                playForm caForm2 = new playForm();
                this.Hide();
                caForm2.ShowDialog();
            }
            else
            {
                userPassError.Show();
            }
        }

        private void userAccountCreationBtn_Click(object sender, EventArgs e)
        {
            newUserCreation caForm = new newUserCreation();
            this.Hide();
            caForm.ShowDialog();
        }
        /*for each value in the db search compare it to username
* if username is equal to a value in the database
* check if password does not match the password in the database
* display error message
* clear the text boxes */
        //usernameTxtBox.Clear();
        //passwordTxtBox.Clear();
    }


}
