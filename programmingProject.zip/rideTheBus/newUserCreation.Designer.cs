﻿namespace rideTheBus
{
    partial class newUserCreation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.newUser = new System.Windows.Forms.GroupBox();
            this.userTakenErrorLbl = new System.Windows.Forms.Label();
            this.passwordTxtBox2 = new System.Windows.Forms.TextBox();
            this.usernameTxtBox2 = new System.Windows.Forms.TextBox();
            this.passwordLbl2 = new System.Windows.Forms.Label();
            this.usernameLbl2 = new System.Windows.Forms.Label();
            this.newCreationSubmitBtn = new System.Windows.Forms.Button();
            this.backToLoginBtn = new System.Windows.Forms.Button();
            this.newUser.SuspendLayout();
            this.SuspendLayout();
            // 
            // newUser
            // 
            this.newUser.Controls.Add(this.backToLoginBtn);
            this.newUser.Controls.Add(this.newCreationSubmitBtn);
            this.newUser.Controls.Add(this.userTakenErrorLbl);
            this.newUser.Controls.Add(this.passwordTxtBox2);
            this.newUser.Controls.Add(this.usernameTxtBox2);
            this.newUser.Controls.Add(this.passwordLbl2);
            this.newUser.Controls.Add(this.usernameLbl2);
            this.newUser.Location = new System.Drawing.Point(253, 109);
            this.newUser.Name = "newUser";
            this.newUser.Size = new System.Drawing.Size(241, 232);
            this.newUser.TabIndex = 5;
            this.newUser.TabStop = false;
            this.newUser.Text = "New User Sign Up";
            // 
            // userTakenErrorLbl
            // 
            this.userTakenErrorLbl.AutoSize = true;
            this.userTakenErrorLbl.ForeColor = System.Drawing.Color.Red;
            this.userTakenErrorLbl.Location = new System.Drawing.Point(100, 20);
            this.userTakenErrorLbl.Name = "userTakenErrorLbl";
            this.userTakenErrorLbl.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.userTakenErrorLbl.Size = new System.Drawing.Size(95, 13);
            this.userTakenErrorLbl.TabIndex = 8;
            this.userTakenErrorLbl.Text = "Username is taken";
            // 
            // passwordTxtBox2
            // 
            this.passwordTxtBox2.Location = new System.Drawing.Point(100, 81);
            this.passwordTxtBox2.Name = "passwordTxtBox2";
            this.passwordTxtBox2.PasswordChar = '*';
            this.passwordTxtBox2.Size = new System.Drawing.Size(100, 20);
            this.passwordTxtBox2.TabIndex = 7;
            // 
            // usernameTxtBox2
            // 
            this.usernameTxtBox2.Location = new System.Drawing.Point(100, 47);
            this.usernameTxtBox2.Name = "usernameTxtBox2";
            this.usernameTxtBox2.Size = new System.Drawing.Size(100, 20);
            this.usernameTxtBox2.TabIndex = 6;
            // 
            // passwordLbl2
            // 
            this.passwordLbl2.AutoSize = true;
            this.passwordLbl2.Location = new System.Drawing.Point(41, 81);
            this.passwordLbl2.Name = "passwordLbl2";
            this.passwordLbl2.Size = new System.Drawing.Size(52, 13);
            this.passwordLbl2.TabIndex = 5;
            this.passwordLbl2.Text = "password";
            // 
            // usernameLbl2
            // 
            this.usernameLbl2.AutoSize = true;
            this.usernameLbl2.Location = new System.Drawing.Point(41, 47);
            this.usernameLbl2.Name = "usernameLbl2";
            this.usernameLbl2.Size = new System.Drawing.Size(53, 13);
            this.usernameLbl2.TabIndex = 4;
            this.usernameLbl2.Text = "username";
            // 
            // newCreationSubmitBtn
            // 
            this.newCreationSubmitBtn.Location = new System.Drawing.Point(100, 118);
            this.newCreationSubmitBtn.Name = "newCreationSubmitBtn";
            this.newCreationSubmitBtn.Size = new System.Drawing.Size(75, 23);
            this.newCreationSubmitBtn.TabIndex = 10;
            this.newCreationSubmitBtn.Text = "submit";
            this.newCreationSubmitBtn.UseVisualStyleBackColor = true;
            this.newCreationSubmitBtn.Click += new System.EventHandler(this.newCreationSubmitBtn_Click);
            // 
            // backToLoginBtn
            // 
            this.backToLoginBtn.Location = new System.Drawing.Point(0, 188);
            this.backToLoginBtn.Name = "backToLoginBtn";
            this.backToLoginBtn.Size = new System.Drawing.Size(235, 23);
            this.backToLoginBtn.TabIndex = 11;
            this.backToLoginBtn.Text = "Go back to login";
            this.backToLoginBtn.UseVisualStyleBackColor = true;
            this.backToLoginBtn.Click += new System.EventHandler(this.backToLoginBtn_Click);
            // 
            // newUserCreation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.newUser);
            this.Name = "newUserCreation";
            this.Text = "newUserCreation";
            this.newUser.ResumeLayout(false);
            this.newUser.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox newUser;
        private System.Windows.Forms.Label userTakenErrorLbl;
        private System.Windows.Forms.TextBox passwordTxtBox2;
        private System.Windows.Forms.TextBox usernameTxtBox2;
        private System.Windows.Forms.Label passwordLbl2;
        private System.Windows.Forms.Label usernameLbl2;
        private System.Windows.Forms.Button newCreationSubmitBtn;
        private System.Windows.Forms.Button backToLoginBtn;
    }
}