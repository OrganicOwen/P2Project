﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace rideTheBus
{
    public partial class newUserCreation : Form
    {
        public newUserCreation()
        {
            InitializeComponent();
            userTakenErrorLbl.Hide();
        }
        
        string newPassword;
        string newUsername;
        string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\lamarraoa57\\OneDrive - Northwood University\\Programming\\rideTheBus\\Database1.mdf\";Integrated Security=True";
        private void newCreationSubmitBtn_Click(object sender, EventArgs e)
        {
            newUsername = usernameTxtBox2.Text;
            newPassword = passwordTxtBox2.Text;
            /*for each value in the db search compare it to username
             * if username is equal to a value in the database
             * display error message
             * clear the text boxes */
            SqlConnection conn = new SqlConnection(connectionString);
            //SqlCommand maxCommand = new SqlCommand("SELECT max(ID) from StateTaxes ", conn); (read command)
            try
            { //insert new state
                conn.Open();
                string usernamePassword = "INSERT INTO [user] (username, password)VALUES('" + newUsername + "','" + newPassword+"')";

                SqlCommand insertStatecmd = new SqlCommand(usernamePassword, conn);
                insertStatecmd.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("Data saved successfuly...!");
                
            }
            catch (Exception ex)
            {
                //MessageBox.Show("Failed due to" + ex.Message);
                userTakenErrorLbl.Show();
            }
            conn.Close();
        }

        private void backToLoginBtn_Click(object sender, EventArgs e)
        {
            loginPage caForm = new loginPage();
            this.Hide();
            caForm.ShowDialog();
        }
    }
}
