﻿namespace rideTheBus
{
    partial class playForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.submitBtn = new System.Windows.Forms.Button();
            this.responseCB = new System.Windows.Forms.ComboBox();
            this.cardLstBox = new System.Windows.Forms.ListBox();
            this.nxtBtn = new System.Windows.Forms.Button();
            this.loseLbl = new System.Windows.Forms.Label();
            this.startBtn = new System.Windows.Forms.Button();
            this.playAgainBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // submitBtn
            // 
            this.submitBtn.Location = new System.Drawing.Point(242, 199);
            this.submitBtn.Name = "submitBtn";
            this.submitBtn.Size = new System.Drawing.Size(75, 23);
            this.submitBtn.TabIndex = 2;
            this.submitBtn.Text = "Submit";
            this.submitBtn.UseVisualStyleBackColor = true;
            this.submitBtn.Click += new System.EventHandler(this.submitBtn_Click);
            // 
            // responseCB
            // 
            this.responseCB.FormattingEnabled = true;
            this.responseCB.Location = new System.Drawing.Point(242, 174);
            this.responseCB.Name = "responseCB";
            this.responseCB.Size = new System.Drawing.Size(121, 21);
            this.responseCB.TabIndex = 3;
            this.responseCB.Text = "Responses";
            // 
            // cardLstBox
            // 
            this.cardLstBox.FormattingEnabled = true;
            this.cardLstBox.Location = new System.Drawing.Point(396, 156);
            this.cardLstBox.Name = "cardLstBox";
            this.cardLstBox.Size = new System.Drawing.Size(120, 95);
            this.cardLstBox.TabIndex = 4;
            // 
            // nxtBtn
            // 
            this.nxtBtn.Location = new System.Drawing.Point(560, 172);
            this.nxtBtn.Name = "nxtBtn";
            this.nxtBtn.Size = new System.Drawing.Size(75, 23);
            this.nxtBtn.TabIndex = 5;
            this.nxtBtn.Text = "Next Question";
            this.nxtBtn.UseVisualStyleBackColor = true;
            this.nxtBtn.Click += new System.EventHandler(this.nxtBtn_Click);
            // 
            // loseLbl
            // 
            this.loseLbl.AutoSize = true;
            this.loseLbl.ForeColor = System.Drawing.Color.Red;
            this.loseLbl.Location = new System.Drawing.Point(239, 156);
            this.loseLbl.Name = "loseLbl";
            this.loseLbl.Size = new System.Drawing.Size(58, 13);
            this.loseLbl.TabIndex = 6;
            this.loseLbl.Text = "Start Over!";
            // 
            // startBtn
            // 
            this.startBtn.Location = new System.Drawing.Point(130, 174);
            this.startBtn.Name = "startBtn";
            this.startBtn.Size = new System.Drawing.Size(75, 23);
            this.startBtn.TabIndex = 7;
            this.startBtn.Text = "Start!";
            this.startBtn.UseVisualStyleBackColor = true;
            this.startBtn.Click += new System.EventHandler(this.startBtn_Click);
            // 
            // playAgainBtn
            // 
            this.playAgainBtn.Location = new System.Drawing.Point(267, 304);
            this.playAgainBtn.Name = "playAgainBtn";
            this.playAgainBtn.Size = new System.Drawing.Size(170, 23);
            this.playAgainBtn.TabIndex = 8;
            this.playAgainBtn.Text = "Back to Login";
            this.playAgainBtn.UseVisualStyleBackColor = true;
            this.playAgainBtn.Click += new System.EventHandler(this.playAgainBtn_Click);
            // 
            // playForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.playAgainBtn);
            this.Controls.Add(this.startBtn);
            this.Controls.Add(this.loseLbl);
            this.Controls.Add(this.nxtBtn);
            this.Controls.Add(this.cardLstBox);
            this.Controls.Add(this.responseCB);
            this.Controls.Add(this.submitBtn);
            this.Name = "playForm";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button submitBtn;
        private System.Windows.Forms.ComboBox responseCB;
        private System.Windows.Forms.ListBox cardLstBox;
        private System.Windows.Forms.Button nxtBtn;
        private System.Windows.Forms.Label loseLbl;
        private System.Windows.Forms.Button startBtn;
        private System.Windows.Forms.Button playAgainBtn;
    }
}