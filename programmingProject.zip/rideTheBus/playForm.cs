﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace rideTheBus
{
    public partial class playForm : Form
    {
        public playForm()
        {
            InitializeComponent();
        }
        string[] cardLst = {"1,H", "2,H", "3,H", "4,H", "5,H", "6,H", "7,H", "8,H", "9,H", "10,H", "11,H", "12,H", "13,H",
            "1,D", "2,D", "3,D", "4,D", "5,D", "6,D", "7,D", "8,D", "9,D", "10,D", "11,D", "12,D", "13,D",
        "1,S", "2,S", "3,S","4,S", "5,S", "6,S", "7,S", "8,S", "9,S", "10,S", "11,S", "12,S", "13,S",
        "1,C", "2,C", "3,C", "4,C", "5,C", "6,C", "7,C", "8,C", "9,C", "10,C", "11,C", "12,C", "13,C"};
        string[] question1 = { "Red or Black?", "Red", "Black" };
        string[] question2 = { "Higher or Lower?", "Higher", "Lower" };
        string[] question3 = { "In between or outside?", "In", "Out" };
        string[] question4 = { "What suit?", "Hearts", "Spades", "Diamonds", "Clubs" };
        int count = 1;
        bool isCorrect = true;
        //string[] cardsInPlay;
        string selectedQ;
        private void submitBtn_Click(object sender, EventArgs e)
        {
            //get the answer from the combo box
            int randomNumber;
            Random RNG = new Random();
            randomNumber = RNG.Next(0, 51);
            string randomCard = cardLst[randomNumber];
            //cardsInPlay.Append(randomCard);
            cardLstBox.Items.Add(randomCard);
            selectedQ = (string)responseCB.SelectedItem;
            //string num = randomCard.Substring(0);
            //Convert.ToInt16 = num;
            switch(count)
            {
                case 1://is question 1
                    if(selectedQ == question1[1])//guess is red
                    {
                        //test if card is red
                    }
                    else if(selectedQ == question1[2])//guess is black
                    {
                        //test if card is black
                    }
                    else //chose the question option
                    {
                        count = 1;
                        loseLbl.Show();
                    }
                    break;
                case 2://is question 2
                    if (selectedQ == question2[1])//guess is higher
                    {
                        //test if card is higher
                    }
                    else if (selectedQ == question2[2])//guess is lower
                    {
                        //test if card is lower
                    }
                    else //chose the question option
                    {
                        count = 1;
                        loseLbl.Show();
                    }
                    break;
                case 3://is question 3
                    if (selectedQ == question3[1])//guess is in
                    {
                        //test if card is in
                    }
                    else if (selectedQ == question3[2])//guess is out
                    {
                        //test if card is out
                    }
                    else //chose the question option
                    {
                        count = 1;
                        loseLbl.Show();
                    }
                    break;
                case 4://is question 4
                    if (selectedQ == question4[1])//guess is hearts
                    {
                        //test if card is a heart
                    }
                    else if (selectedQ == question4[2])//guess is spades
                    {
                        //test if card is a spade
                    }
                    else if(selectedQ == question4[3])//guess is diamonds
                    {
                        //test if card is a diamond
                    }
                    else if(selectedQ == question4[4])//guess is clubs
                    {
                        //test if card is a club
                    }
                    else //chose the question option
                    {
                        count = 1;
                        loseLbl.Show();
                    }
                    break;
            }
            count++;
        }

        private void startBtn_Click(object sender, EventArgs e)
        {
            //starts the game with the first question
            responseCB.DataSource = question1;
            loseLbl.Hide();

        }

        private void playAgainBtn_Click(object sender, EventArgs e)
        {
            loginPage caForm = new loginPage();
            this.Hide();
            caForm.ShowDialog();

        }

        private void nxtBtn_Click(object sender, EventArgs e)
        {
            //checks your answer
            //gives next question if correct else loops back to question 1
            //figure out how to pull the selection from the combo box
            //cardLstBox.Items.Clear();
            //get the values separated by commas from the given cards and place them into new values
            //an array with the current numbers ordered lowest to highest
            loseLbl.Hide();
            //moves the game along depending on which question you are on using count to determine which question
            switch (count)
            {
                case 1:
                    responseCB.DataSource = question1;
                    break;
                case 2:
                    responseCB.DataSource = question2;
                    break;
                case 3:
                    responseCB.DataSource = question3;
                    break;
                case 4:
                    responseCB.DataSource = question4;
                    break;

            }
        }
    }
}
