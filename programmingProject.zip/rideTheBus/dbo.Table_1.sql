﻿CREATE TABLE [dbo].[match] (
    [matchID] INT NOT NULL,
    [dateNtime] DATETIME NOT NULL,
    [username] VARCHAR(50) NOT NULL, 
    [rounds] INT NOT NULL, 
    PRIMARY KEY CLUSTERED ([matchID] ASC)
);

