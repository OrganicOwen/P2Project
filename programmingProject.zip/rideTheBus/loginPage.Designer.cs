﻿namespace rideTheBus
{
    partial class loginPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LoginPage = new System.Windows.Forms.TabPage();
            this.userAccountCreationBtn = new System.Windows.Forms.Button();
            this.userPassError = new System.Windows.Forms.Label();
            this.createAccountLink = new System.Windows.Forms.LinkLabel();
            this.submitButton = new System.Windows.Forms.Button();
            this.passwordTxtBox = new System.Windows.Forms.TextBox();
            this.usernameTxtBox = new System.Windows.Forms.TextBox();
            this.passwordLbl = new System.Windows.Forms.Label();
            this.usernameLbl = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.LoginPage.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // LoginPage
            // 
            this.LoginPage.Controls.Add(this.userAccountCreationBtn);
            this.LoginPage.Controls.Add(this.userPassError);
            this.LoginPage.Controls.Add(this.createAccountLink);
            this.LoginPage.Controls.Add(this.submitButton);
            this.LoginPage.Controls.Add(this.passwordTxtBox);
            this.LoginPage.Controls.Add(this.usernameTxtBox);
            this.LoginPage.Controls.Add(this.passwordLbl);
            this.LoginPage.Controls.Add(this.usernameLbl);
            this.LoginPage.Location = new System.Drawing.Point(4, 22);
            this.LoginPage.Name = "LoginPage";
            this.LoginPage.Padding = new System.Windows.Forms.Padding(3);
            this.LoginPage.Size = new System.Drawing.Size(798, 432);
            this.LoginPage.TabIndex = 0;
            this.LoginPage.Text = "Login";
            this.LoginPage.UseVisualStyleBackColor = true;
            // 
            // userAccountCreationBtn
            // 
            this.userAccountCreationBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userAccountCreationBtn.Location = new System.Drawing.Point(254, 197);
            this.userAccountCreationBtn.Name = "userAccountCreationBtn";
            this.userAccountCreationBtn.Size = new System.Drawing.Size(230, 23);
            this.userAccountCreationBtn.TabIndex = 9;
            this.userAccountCreationBtn.Text = "Don\'t have an account? Create One!";
            this.userAccountCreationBtn.UseVisualStyleBackColor = true;
            this.userAccountCreationBtn.Click += new System.EventHandler(this.userAccountCreationBtn_Click);
            // 
            // userPassError
            // 
            this.userPassError.AutoSize = true;
            this.userPassError.ForeColor = System.Drawing.Color.Red;
            this.userPassError.Location = new System.Drawing.Point(274, 73);
            this.userPassError.Name = "userPassError";
            this.userPassError.Size = new System.Drawing.Size(169, 13);
            this.userPassError.TabIndex = 7;
            this.userPassError.Text = "Username or password is incorrect";
            // 
            // createAccountLink
            // 
            this.createAccountLink.Location = new System.Drawing.Point(0, 0);
            this.createAccountLink.Name = "createAccountLink";
            this.createAccountLink.Size = new System.Drawing.Size(100, 23);
            this.createAccountLink.TabIndex = 8;
            // 
            // submitButton
            // 
            this.submitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.submitButton.Location = new System.Drawing.Point(346, 168);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(70, 23);
            this.submitButton.TabIndex = 5;
            this.submitButton.Text = "submit";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // passwordTxtBox
            // 
            this.passwordTxtBox.Location = new System.Drawing.Point(333, 132);
            this.passwordTxtBox.Name = "passwordTxtBox";
            this.passwordTxtBox.PasswordChar = '*';
            this.passwordTxtBox.Size = new System.Drawing.Size(100, 20);
            this.passwordTxtBox.TabIndex = 3;
            // 
            // usernameTxtBox
            // 
            this.usernameTxtBox.Location = new System.Drawing.Point(333, 98);
            this.usernameTxtBox.Name = "usernameTxtBox";
            this.usernameTxtBox.Size = new System.Drawing.Size(100, 20);
            this.usernameTxtBox.TabIndex = 2;
            // 
            // passwordLbl
            // 
            this.passwordLbl.AutoSize = true;
            this.passwordLbl.Location = new System.Drawing.Point(274, 132);
            this.passwordLbl.Name = "passwordLbl";
            this.passwordLbl.Size = new System.Drawing.Size(52, 13);
            this.passwordLbl.TabIndex = 1;
            this.passwordLbl.Text = "password";
            // 
            // usernameLbl
            // 
            this.usernameLbl.AutoSize = true;
            this.usernameLbl.Location = new System.Drawing.Point(274, 98);
            this.usernameLbl.Name = "usernameLbl";
            this.usernameLbl.Size = new System.Drawing.Size(53, 13);
            this.usernameLbl.TabIndex = 0;
            this.usernameLbl.Text = "username";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.LoginPage);
            this.tabControl1.Location = new System.Drawing.Point(-1, -4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(806, 458);
            this.tabControl1.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.LoginPage.ResumeLayout(false);
            this.LoginPage.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TabPage LoginPage;
        private System.Windows.Forms.Button userAccountCreationBtn;
        private System.Windows.Forms.Label userPassError;
        private System.Windows.Forms.LinkLabel createAccountLink;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.TextBox passwordTxtBox;
        private System.Windows.Forms.TextBox usernameTxtBox;
        private System.Windows.Forms.Label passwordLbl;
        private System.Windows.Forms.Label usernameLbl;
        private System.Windows.Forms.TabControl tabControl1;
    }
}

